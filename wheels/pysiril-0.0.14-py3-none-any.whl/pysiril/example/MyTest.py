# -*- coding: UTF-8 -*-
# ==============================================================================

# ------------------------------------------------------------------------------
# Project: pysiril ( Python SiriL )
#
# This is a library to interface python to Siril.
# ------------------------------------------------------------------------------
#    Author:  M27trognondepomme <pebe92 (at) gmail.com>
#
# This program is provided without any guarantee.
#
# The license is  LGPL-v3
# For details, see GNU General Public License, version 3 or later.
#                        "https://www.gnu.org/licenses/gpl.html"
# ------------------------------------------------------------------------------

import sys
import os

try:
    from pysiril.siril   import *
    from pysiril.wrapper import *
    from pysiril.addons  import *
except:
    print(" ***  Mode Developement - la lib pysiril n'est pas installe *** ")
    path_exec=os.path.dirname(  __file__ )
    if not path_exec :
        path_exec='.'
    sys.path.append(path_exec + os.sep + '..')
    from siril   import *
    from wrapper import *
    from addons  import *

# ==============================================================================
# Example of functions which return values
# ==============================================================================

print("StatusFunctions:begin")
app=Siril("C:/awin/msys64/mingw64/bin/siril.exe", True)
#try:
cmd=Wrapper(app)
fct=Addons(app)
#app.Display(bLog=True,bInfo=False)
#app.MuteSiril(True)
app.Open()

if sys.platform.startswith('win32'): 
    workdir="D:/_TraitAstro/20-SiriL/work/M101/Temp"
    image="../M101_c.fit"
else:
    workdir="/home/barch/siril/work"
    image="M31_DSLR"
    
app.Execute("cd '"  + workdir +"'")
app.Execute("load '"+ image  +"'")

if False :
    cmd.help()
    cmd.help("xxx")
    cmd.help("stack")
    help( cmd.stack )


#print("autostretch:",cmd.autostretch())
#print("autostretch:",cmd.autostretch(linked=True))
#print("autostretch:",cmd.autostretch(shadowsclip=-1.8,targetbg=0.35) ) 
#print("asinh:",cmd.asinh(10))
#print("asinh:",cmd.asinh(100,offset=0.65,human=True))
#print("asinh:",cmd.asinh(100,offset=0.35) ) 
#print("BG:" ,cmd.bg())
#print("BGNOISE:" ,cmd.bgnoise())
#print("binxy:" ,cmd.binxy(2) )
#print("binxy:" ,cmd.binxy(3,sum=True) )
#print("boxselect:" ,cmd.boxselect(2,3,56,35) )
#print("boxselect:" ,cmd.boxselect() )
#print("boxselect:" ,cmd.boxselect(clear=True) )
#print("boxselect:" ,cmd.boxselect() )
#print("capabilities:" ,cmd.capabilities() )
#print("cdg:" ,cmd.cdg() )
#print("clahe:" ,cmd.clahe(0.8,8) )
#print("cosme:" ,cmd.cosme("M101_c.lst'") )
#print("boxselect:" ,cmd.boxselect(clear=True) )
#print("crop:" ,cmd.crop() )
#print("boxselect:" ,cmd.boxselect(2,3,556,435) )
#print("crop:" ,cmd.crop() )
#print("crop:" ,cmd.crop(2,3,56,35) )
#status,hd=cmd.dumpheader()
#print("dumpheader:" , status )
#for line in hd : print(line )
#print("entropy:" ,cmd.entropy() )
#print("extract:" ,cmd.extract(5) )
#print("extract_Green:" ,cmd.extract_Green() )
#print("extract_Ha:" ,cmd.extract_Ha() )
#print("extract_HaOIII:" ,cmd.extract_HaOIII() )
#print("extract_HaOIII:" ,cmd.extract_HaOIII(resample="ha") )
#print("extract_HaOIII:" ,cmd.extract_HaOIII(resample="oiii") )
#print("fdiv:" ,cmd.fdiv('r_C0',4) )
#print("fftd:" ,cmd.fftd('module','phase') )
#print("ffti:" ,cmd.ffti('module','phase') )
#print("fill:" ,cmd.fill(55,2,3,556,435) )
#print("fill:" ,cmd.fill(155) )
#print("fill2:" ,cmd.fill2(55,2,3,556,435) )
#print("select:" ,cmd.boxselect(2,3,56,35) )
#print("fill2:" ,cmd.fill2(155) )
#cmd.load('master-dark.fit')
#print("find_cosme:" ,cmd.find_cosme(4,4) )
#print("find_cosme_cfa:" ,cmd.find_cosme_cfa(3,1) )
#print("find_hot:" ,cmd.find_hot('master-dark',3,3) )
#print("findstar:" ,cmd.findstar() )
#print("findstar:" ,cmd.findstar("toto.txt",2,100) )
#print("findstar:" ,cmd.findstar(out="titi.txt",maxstars=100) )
#print("findstar:" ,cmd.findstar(layer=2) )
#print("fixbanding:" ,cmd.fixbanding(23,5) )
#print("fixbanding:" ,cmd.fixbanding(23,5,vertical=True) )
#print("fmedian:" ,cmd.fmedian(3,0.25) )
#print("fmul:" ,cmd.fmul(0.75) )
#print("gauss:" ,cmd.gauss(0.75) )
#print("get:" ,cmd.get(a=True) )
#print("get:" ,cmd.get(A=True) )
#print("get:" ,cmd.get("core.rgb_aladin") )
#print("ght:" ,cmd.ght(1,-1,0.15,0.75,1) )
#print("ght:" ,cmd.ght(1,-1,0.15,0.75,1,channels=2,even=True) )
#print("ght:" ,cmd.ght(1,-1,0.15,0.75,1,human=True) )
#print("ght:" ,cmd.ght(1,-1,0.15,0.75,1,even=True) )
#print("ght:" ,cmd.ght(1,-1,0.15,0.75,1,independent=True) )
#cmd.load('master-flat.fit')
#print("grey_flat:" ,cmd.grey_flat() )
#help(Wrapper.histo)
#print("help:", cmd.help("histo"))
#print("histo:", cmd.histo(0))
#cmd.load('r_C1')
#print("iadd:", cmd.iadd('r_C0'))
#print("idiv:", cmd.idiv('r_C0'))
#print("invght:" ,cmd.invght(1,-1,0.15,0.75,1) )
#print("invght:" ,cmd.invght(1,-1,0.15,0.75,1,channels=2,even=True) )
#print("invght:" ,cmd.invght(1,-1,0.15,0.75,1,human=True) )
#print("invght:" ,cmd.invght(1,-1,0.15,0.75,1,even=True) )
#print("invght:" ,cmd.invght(1,-1,0.15,0.75,1,independent=True) )
#print("invmodasinh:" ,cmd.invmodasinh(1,0.15,0.75,1) )
#print("invmodasinh:" ,cmd.invmodasinh(1,0.15,0.75,1,channels=2,even=True) )
#print("invmodasinh:" ,cmd.invmodasinh(1,0.15,0.75,1,human=True) )
#print("invmodasinh:" ,cmd.invmodasinh(1,0.15,0.75,1,even=True) )
#print("invmodasinh:" ,cmd.invmodasinh(1,0.15,0.75,1,independent=True) )
#print("invmtf:" ,cmd.invmtf(0.2,0.5,0.8) )
#print("invmtf:" ,cmd.invmtf(0.2,0.5,0.8,channels=1) )
#cmd.load('r_C1')
#print("imul:", cmd.imul('r_C0'))
#print("isub:", cmd.isub('r_C2'))
#print("jsonmetadata:", cmd.jsonmetadata('r_C2.fit'))
#print("jsonmetadata:", cmd.jsonmetadata('r_C2.fit',out='toto.txt'))
#cmd.load('r_C1')
#print("linear_match:", cmd.linear_match('r_C0', 0.15,0.85))
### link
#print("linstretch:", cmd.linstretch(0.12,channels='RG'))
#print("log:", cmd.log())
###  merge
#print("mirrorx:", cmd.mirrorx())
#print("mirrorx:", cmd.mirrorx(bottomup=True))
#print("mirrorx_single:", cmd.mirrorx_single('r_C0.fit'))
#print("mirrory:", cmd.mirrory())
#print("modasinh:" ,cmd.modasinh(1,0.15,0.75,1) )
#print("modasinh:" ,cmd.modasinh(1,0.15,0.75,1,channels=2,even=True) )
#print("modasinh:" ,cmd.modasinh(1,0.15,0.75,1,human=True) )
#print("modasinh:" ,cmd.modasinh(1,0.15,0.75,1,even=True) )
#print("modasinh:" ,cmd.modasinh(1,0.15,0.75,1,independent=True) )
#print("mtf:" ,cmd.mtf(0.2,0.5,0.8) )
#print("mtf:" ,cmd.mtf(0.2,0.5,0.8,channels='RB') )
#print("neg:", cmd.neg())
#print("nozero:", cmd.nozero(1))
#print("offset:", cmd.offset(1))
## parse
## pcc
#print("pm:", cmd.pm("$r_C0$ * 0.5 + $r_C1$ * 0.75 - $r_C2$ * 0.25"))
#print("pm:", cmd.pm("$r_C0$ * 0.5", rescale=True))
#print("pm:", cmd.pm("$r_C0$ * 0.5", rescale=True,low=0.1,high=0.85))
## preprocess
## preprocess_single
#cmd.boxselect(2,3,56,35)
#print("psf:", cmd.psf(1))
## merge_cfa
## register
#print("requires:", cmd.requires("0.99.6"))
#print("requires:", cmd.requires("1.99.6"))
#print("rgbcomp:", cmd.rgbcomp(red="r_C1",green="r_C2",blue="r_C3",out="lrgb1"))
#print("rgbcomp:", cmd.rgbcomp(lum="r_C0",red="r_C1",green="r_C2",blue="r_C3",out="lrgb2"))
#print("rgbcomp:", cmd.rgbcomp(lum="r_C0",rgb_image="lrgb1",out="lrgb3"))
#print("rgradient:", cmd.rgradient(500,1200,1000,15))
#print("rl:", cmd.rl(1.1,0.12,5))
#print("rmgreen:", cmd.rmgreen())
#print("rmgreen:", cmd.rmgreen(0))
#print("rmgreen:", cmd.rmgreen(1))
#print("rotate:", cmd.rotate(15))
#print("rotate:", cmd.rotate(360-15,nocrop=True))
#print("rotate:", cmd.rotate(5,interp="la", noclamp=True))
#print("rotatepi:", cmd.rotatepi())
#print("satu:", cmd.satu(1.2))
#print("satu:", cmd.satu(1.5,background_factor=5))
#print("satu:", cmd.satu(1.5,hue_range_index=5))
#print("savetif:", cmd.savetif("toto.tif"))
#print("savetif:", cmd.savetif("toto.tif",astro=True))
#print("savetif32:", cmd.savetif32("toto32.tif"))
#print("savetif32:", cmd.savetif32("toto32.tif",astro=True))
#print("savetif8:", cmd.savetif8("toto8.tif"))
#print("savetif8:", cmd.savetif8("toto8.tif",astro=True))
#print("seqheader:", cmd.seqheader("r_C","DATE","EXPTIME"))
## print("seqpsf:", cmd.seqpsf("r_C", 0,at="20,20"))
## print("seqpsf:", cmd.seqpsf("r_C", 0,wcs="20,20"))
#print("seqsplit_cfa:", cmd.seqsplit_cfa("r_C"))
#print("seqmerge_cfa:", cmd.seqmerge_cfa("r_C","RGGB"))
#print("seqsplit_cfa:", cmd.seqsplit_cfa("r_C", prefix="XX_"))
#print("seqmerge_cfa:", cmd.seqmerge_cfa("r_C","RGGB",prefixin="XX_",prefixout="mX_"))
#print("seqstat:", cmd.seqstat("r_C"))
#print("seqstat:", cmd.seqstat("r_C","Test_full_stat.txt",option="full"))
#print("seqstat:", cmd.seqstat("r_C","Test_cfa_main_stat.txt",option="main",cfa=True))
#print("seqstat:", cmd.seqstat("r_C","Test_cfa_basic_stat.txt",cfa=True))
#print("seqsubsky:", cmd.seqsubsky("r_C",1))
#print("seqsubsky:", cmd.seqsubsky("r_C",rbf=True))
#print("seqsubsky:", cmd.seqsubsky("r_C",rbf=True,samples=21,tolerance=0.9,smooth=0.4))
#print("seqtilt:", cmd.seqtilt("r_C") )
## cmd.seqsubsky("r_C",1)
## print("seqtilt:", cmd.seqtilt())
#with open(os.path.join(workdir,"config.txt"), "w") as fichier:
#    fichier.write("""
#[starfinder]
#focal_length = 259.7
#pixel_size = 2.4
#""")
#print("set:" ,cmd.set("starfinder.focal_length=600",) )
#print("set:" ,cmd.set("starfinder.pixel_size=3.75") )
#cmd.get("starfinder.focal_length")
#cmd.get("starfinder.pixel_size")
#print("set:" ,cmd.set(inifile="'config.txt'") )
#cmd.get("starfinder.focal_length")
#cmd.get("starfinder.pixel_size")
#print("setcompress:" ,cmd.setcompress(0) )
#print("setcompress:" ,cmd.setcompress(1,type="rice") )
#print("setcompress:" ,cmd.setcompress(1,type="gzip1",quantif=4) )
#print("setcpu:" ,cmd.setcpu(7) )
#print("setext:" ,cmd.setext("fit") )
#print("setfindstar:" ,cmd.setfindstar("reset",radius=15) )
#print("setfindstar:" ,cmd.setfindstar(relax=1,sigma=3) )
#print("setfindstar:" ,cmd.setfindstar(relax=0,roundness=0.9) )
#print("setfindstar:" ,cmd.setfindstar(relax=True,focal=256.3) )
#print("setfindstar:" ,cmd.setfindstar(relax=False,pixelsize=2.1) )
#print("setfindstar:" ,cmd.setfindstar(relax="on",convergence=1) )
#print("setfindstar:" ,cmd.setfindstar(relax="off",gaussian=True) )
#print("setfindstar:" ,cmd.setfindstar(moffat=True) )
#print("setfindstar:" ,cmd.setfindstar(moffat=True,minbeta=2) )
#print("setfindstar:" ,cmd.setfindstar(True) )
#print("setfindstar:" ,cmd.setfindstar() )
#print("setmem:" ,cmd.setmem(0.9) )
#print("setphot:" ,cmd.setphot() )
#print("setphot:" ,cmd.setphot(force_radius=True) )
#print("setphot:" ,cmd.setphot(force_radius=False) )
#print("setref:", cmd.setref("r_C",2) )
## print("solsys:", cmd.solsys() )
## stack
## stackall
## start_ls
## stop_ls
## stackall
#print("stat:" ,cmd.stat() )
#print("subsky:", cmd.subsky(1))
#print("subsky:", cmd.subsky(rbf=True))
#print("subsky:", cmd.subsky(rbf=True,samples=21,tolerance=0.9,smooth=0.4))
#print("synthstar:", cmd.synthstar())
#print("threshlo:", cmd.threshlo(1000))
#print("threshhi:", cmd.threshhi(60000))
#print("thresh:", cmd.thresh(1200,58000))
#print("unclipstars:", cmd.unclipstars())
#print("unsharp:", cmd.unsharp(3,5))
#print("wavelet:", cmd.wavelet(5,1))
## print("wrecons:", cmd.wrecons("5,1"))
    
#except Exception as e :
#    print("\n**** ERROR *** " +  str(e) + "\n" )    

app.Close()
del app

print("StatusFunctions:end")
       
